
import { funcApi } from "./addElement.js";

  let coment = [];

  let token = "Bearer asb4c4boc86gasb4c4boc86g37w3cc3bo3b83k4g37k3bk3cg3c03ck4k";

  funcApi();



  

  

  
    


  
 