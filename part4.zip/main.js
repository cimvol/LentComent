
import { addElement } from "./addElement.js";
import { funcApi } from "./addElement.js";
import { renderComent } from "./renderComent.js";
import { polComent } from "./api.js";


  let coment = [];

  //let token = "asb4c4boc86gasb4c4boc86g37w3cc3bo3b83k4g37k3bk3cg3c03ck4k";

  funcApi();

  
    


  
 